#ifndef NULLSOFT_FANZONE_MAIN_H
#define NULLSOFT_FANZONE_MAIN_H

#include "ml_fanzone_global.h"

#include <QtGlobal>
#include <QObject>
#include <QString>

#include <windows.h>
#include "../Plugins/General/gen_ml/ml.h"
#include "../nu/MediaLibraryInterface.h"
#include "resource.h"
#include <windowsx.h>
#include "../winamp/wa_ipc.h"
#include "../Plugins/General/gen_ml/config.h"
#include "api_ml_fanzone.h"

#define FANZONE_BASE_URL    L"https://www.winamp.com/"


INT_PTR pluginMessageProc( int p_message_type, INT_PTR p_param1, INT_PTR p_param2, INT_PTR p_param3 );

extern winampMediaLibraryPlugin g_plugin;
extern int                      g_treeItem;



#endif  // !NULLSOFT_FANZONE_MAIN_H

//
//class ML_FANZONE_EXPORT ml_fanzone
//{
//public:
//    ml_fanzone();
//};
