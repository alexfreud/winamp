#include <strsafe.h>

#include "main.h"

#include "../nu/DialogSkinner.h"
#include "../nu/ListView.h"

#include "../../General/gen_ml/ml_ipc.h"
#include "../../General/gen_ml/menu.h"

#include "../WAT/WAT.h"

INT_PTR CALLBACK viewDialogProc( HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam );

static W_ListView  _list_view;
static HWND        _headerhwnd;
static HWND        _hwnd;
extern C_Config   *g_config;
//extern char       *g_ext_list;
static int         _customAllowed;
static viewButtons _view;

//C_Config *g_wa_config = Q_NULLPTR;
//char     *g_ext_list  = 0;

// used for the send-to menu bits
static INT_PTR                 IPC_LIBRARY_SENDTOMENU;
static librarySendToMenuStruct _sendToMenu;

extern HMENU   g_context_menus;
extern HMENU   g_context_menus2;
extern HCURSOR g_hDragNDropCursor;


static int pluginContextMenu( INT_PTR p_param1, HWND p_hHost, POINTS p_pts )
{
	Q_UNUSED( p_param1 )
	Q_UNUSED( p_hHost )
	Q_UNUSED( p_pts )

	return TRUE;
}

static int pluginHandleIpcMessage( int p_msg, int p_param )
{
	return (int)SendMessage( g_plugin.hwndLibraryParent, WM_ML_IPC, p_param, p_msg );
}

INT_PTR pluginMessageProc( int p_message_type, INT_PTR p_param1, INT_PTR p_param2, INT_PTR p_param3 )
{
	if ( p_message_type == ML_MSG_NO_CONFIG )
	{
		return TRUE;
	}
	else if ( p_message_type == ML_MSG_TREE_ONCREATEVIEW && p_param1 == g_treeItem )
	{
		return (INT_PTR)WASABI_API_CREATEDIALOGW( IDD_VIEW_FANZONE, (HWND)p_param2, viewDialogProc );
	}
	else if ( p_message_type == ML_MSG_NAVIGATION_CONTEXTMENU )
	{
		return pluginContextMenu( p_param1, (HWND)p_param2, MAKEPOINTS( p_param3 ) );
	}
	else if ( p_message_type == ML_MSG_ONSENDTOSELECT || p_message_type == ML_MSG_TREE_ONDROPTARGET )
	{
		// set with droptarget defaults =)
		UINT_PTR l_type = 0;
		UINT_PTR l_data = 0;

		if ( p_message_type == ML_MSG_ONSENDTOSELECT )
		{
			if ( p_param3 != (INT_PTR)pluginMessageProc ) return 0;

			l_type = (int)p_param1;
			l_data = (int)p_param2;
		}
		else
		{
			if ( p_param1 != g_treeItem ) return 0;

			l_type = (int)p_param2;
			l_data = (int)p_param3;

			if ( !l_data )
			{
				return ( l_type == ML_TYPE_ITEMRECORDLISTW || l_type == ML_TYPE_ITEMRECORDLIST ||
						 l_type == ML_TYPE_FILENAMES || l_type == ML_TYPE_STREAMNAMES ||
						 l_type == ML_TYPE_FILENAMESW || l_type == ML_TYPE_STREAMNAMESW ||
						 l_type == ML_TYPE_CDTRACKS ||
						 l_type == ML_TYPE_PLAYLIST || l_type == ML_TYPE_PLAYLISTS ) ? 1 : -1;
			}
		}
	}

	return 0;
}


static HRGN g_rgnUpdate = NULL;
static int  offsetX     = 0;
static int  offsetY     = 0;

typedef struct _LAYOUT
{
	INT		id;
	HWND	hwnd;
	INT		x;
	INT		y;
	INT		cx;
	INT		cy;
	DWORD	flags;
	HRGN	rgn;
}
LAYOUT, PLAYOUT;

#define SETLAYOUTPOS(_layout, _x, _y, _cx, _cy) { _layout->x=_x; _layout->y=_y;_layout->cx=_cx;_layout->cy=_cy;_layout->rgn=NULL; }
#define SETLAYOUTFLAGS(_layout, _r)																						\
	{																													\
		BOOL fVis;																										\
		fVis = (WS_VISIBLE & (LONG)GetWindowLongPtr(_layout->hwnd, GWL_STYLE));											\
		if (_layout->x == _r.left && _layout->y == _r.top) _layout->flags |= SWP_NOMOVE;									\
		if (_layout->cx == (_r.right - _r.left) && _layout->cy == (_r.bottom - _r.top)) _layout->flags |= SWP_NOSIZE;	\
		if ((SWP_HIDEWINDOW & _layout->flags) && !fVis) _layout->flags &= ~SWP_HIDEWINDOW;								\
		if ((SWP_SHOWWINDOW & _layout->flags) && fVis) _layout->flags &= ~SWP_SHOWWINDOW;									\
	}

#define LAYOUTNEEEDUPDATE(_layout) ((SWP_NOMOVE | SWP_NOSIZE) != ((SWP_NOMOVE | SWP_NOSIZE | SWP_HIDEWINDOW | SWP_SHOWWINDOW) & _layout->flags))

#define GROUP_MIN			0x1
#define GROUP_MAX			0x2

#define GROUP_STATUSBAR		0x1
#define GROUP_MAIN			0x2

static void LayoutWindows( HWND p_hwnd, BOOL p_fRedraw, BOOL p_fUpdateAll = FALSE )
{
	static INT l_controls[] =
	{
		GROUP_STATUSBAR, GROUP_MAIN, IDC_LIST_FANZONE
	};

	RECT    rc;
	RECT    rg;
	RECT    ri;
	LAYOUT  layout[ sizeof( l_controls ) / sizeof( l_controls[ 0 ] ) ];
	LAYOUT *pl  = NULL;
	BOOL    skipgroup;
	HRGN    rgn = NULL;

	GetClientRect( p_hwnd, &rc );
	if ( rc.right == rc.left || rc.bottom == rc.top )
		return;

	int l_scale_X = WASABI_API_APP->getScaleX( 4 );

	if ( rc.right > l_scale_X )
		rc.right -= l_scale_X;

	SetRect( &rg, rc.left, rc.top, rc.right, rc.top );

	pl        = layout;
	skipgroup = FALSE;

	InvalidateRect( p_hwnd, NULL, TRUE );

	for ( int l_index = 0; l_index < sizeof( l_controls ) / sizeof( *l_controls ); ++l_index )
	{
		if ( l_controls[ l_index ] >= GROUP_MIN && l_controls[ l_index ] <= GROUP_MAX ) // group p_id
		{
			skipgroup = FALSE;
			switch ( l_controls[ l_index ] )
			{
				case GROUP_MAIN:
					SetRect( &rg, rc.left + WASABI_API_APP->getScaleX( 1 ), rc.top, rc.right, rc.bottom );
					break;
			}
			continue;
		}

		if ( skipgroup )
			continue;

		pl->id   = l_controls[ l_index ];
		pl->hwnd = GetDlgItem( p_hwnd, pl->id );
		if ( !pl->hwnd )
			continue;

		GetWindowRect( pl->hwnd, &ri );
		MapWindowPoints( HWND_DESKTOP, p_hwnd, (LPPOINT)&ri, 2 );

		pl->flags = SWP_NOZORDER | SWP_NOACTIVATE | SWP_NOREDRAW | SWP_NOCOPYBITS;

		switch ( pl->id )
		{
			case IDC_LIST_FANZONE:
				pl->flags |= ( rg.top < rg.bottom ) ? SWP_SHOWWINDOW : SWP_HIDEWINDOW;
				SETLAYOUTPOS( pl, rg.left, rg.top + WASABI_API_APP->getScaleY( 1 ),
							  rg.right - rg.left + WASABI_API_APP->getScaleY( 1 ),
							  ( rg.bottom - rg.top ) - WASABI_API_APP->getScaleY( 2 ) );
				break;
		}

		SETLAYOUTFLAGS( pl, ri );
		if ( LAYOUTNEEEDUPDATE( pl ) )
		{
			if ( SWP_NOSIZE == ( ( SWP_HIDEWINDOW | SWP_SHOWWINDOW | SWP_NOSIZE ) & pl->flags ) &&
				 ri.left == ( pl->x + offsetX ) && ri.top == ( pl->y + offsetY ) && IsWindowVisible( pl->hwnd ) )
			{
				SetRect( &ri, pl->x, pl->y, pl->cx + pl->x, pl->y + pl->cy );
				ValidateRect( p_hwnd, &ri );
			}

			pl++;
		}
		else if ( ( p_fRedraw || ( !offsetX && !offsetY ) ) && IsWindowVisible( pl->hwnd ) )
		{
			ValidateRect( p_hwnd, &ri );
			if ( GetUpdateRect( pl->hwnd, NULL, FALSE ) )
			{
				if ( !rgn )
					rgn = CreateRectRgn( 0, 0, 0, 0 );

				GetUpdateRgn( pl->hwnd, rgn, FALSE );
				OffsetRgn( rgn, pl->x, pl->y );
				InvalidateRgn( p_hwnd, rgn, FALSE );
			}
		}
	}

	if ( pl != layout )
	{
		LAYOUT *pc;
		HDWP hdwp = BeginDeferWindowPos( (INT)( pl - layout ) );
		for ( pc = layout; pc < pl && hdwp; pc++ )
		{
			hdwp = DeferWindowPos( hdwp, pc->hwnd, NULL, pc->x, pc->y, pc->cx, pc->cy, pc->flags );
		}

		if ( hdwp )
			EndDeferWindowPos( hdwp );

		if ( !rgn )
			rgn = CreateRectRgn( 0, 0, 0, 0 );

		if ( p_fRedraw )
		{
			GetUpdateRgn( p_hwnd, rgn, FALSE );
			for ( pc = layout; pc < pl && hdwp; pc++ )
			{
				if ( pc->rgn )
				{
					OffsetRgn( pc->rgn, pc->x, pc->y );
					CombineRgn( rgn, rgn, pc->rgn, RGN_OR );
				}
			}

			RedrawWindow( p_hwnd, NULL, rgn, RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASENOW | RDW_ALLCHILDREN );
		}

		if ( g_rgnUpdate )
		{
			GetUpdateRgn( p_hwnd, g_rgnUpdate, FALSE );
			for ( pc = layout; pc < pl && hdwp; pc++ )
			{
				if ( pc->rgn )
				{
					OffsetRgn( pc->rgn, pc->x, pc->y );
					CombineRgn( g_rgnUpdate, g_rgnUpdate, pc->rgn, RGN_OR );
				}
			}
		}

		for ( pc = layout; pc < pl && hdwp; pc++ ) if ( pc->rgn ) DeleteObject( pc->rgn );
	}

	if ( rgn )
		DeleteObject( rgn );

	ValidateRgn( p_hwnd, NULL );
}


enum
{
	BPM_ECHO_WM_COMMAND = 0x1, // send WM_COMMAND and return value
	BPM_WM_COMMAND      = 0x2, // just send WM_COMMAND
};

static BOOL plugin_OnDisplayChange()
{
	ListView_SetTextColor( _list_view.getwnd(), dialogSkinner.Color( WADLG_ITEMFG ) );
	ListView_SetBkColor( _list_view.getwnd(), dialogSkinner.Color( WADLG_ITEMBG ) );
	ListView_SetTextBkColor( _list_view.getwnd(), dialogSkinner.Color( WADLG_ITEMBG ) );

	_list_view.SetFont( dialogSkinner.GetFont() );

	LayoutWindows( _hwnd, TRUE );

	return 0;
}

static BOOL plugin_OnCommand( HWND p_hwnd, int p_id, HWND p_hwndCtl, UINT p_codeNotify )
{
	Q_UNUSED( p_hwnd )
	Q_UNUSED( p_id )
	Q_UNUSED( p_hwndCtl )
	Q_UNUSED( p_codeNotify )

	return FALSE;
}

static BOOL plugin_OnDestroy( HWND p_hwnd )
{
	Q_UNUSED( p_hwnd )

	_hwnd = 0;

	return FALSE;
}

static BOOL plugin_OnNotify( HWND p_hwnd, NMHDR *p_notification )
{
	if ( p_notification->idFrom == IDC_LIST_FANZONE )
	{
		if ( p_notification->code == LVN_BEGINDRAG )
		{
			SetCapture( p_hwnd );
		}
	}

	return FALSE;
}

static BOOL plugin_OnInitDialog( HWND p_hwndDlg, HWND p_hwndFocus, LPARAM p_lParam )
{
	_hwnd = p_hwndDlg;

	HWND l_fanzone_handle = GetDlgItem( p_hwndDlg, IDC_LIST_FANZONE );

	_list_view.setwnd( l_fanzone_handle );

	if ( !_view.play )
	{
		SENDMLIPC( g_plugin.hwndLibraryParent, ML_IPC_GET_VIEW_BUTTON_TEXT, (WPARAM)&_view );
	}


	plugin_OnDisplayChange();

	_headerhwnd = ListView_GetHeader( l_fanzone_handle );

	// v5.66+ - re-use the old predixis parts so the button can be used functionally via ml_enqplay
	//			pass the p_hwnd, button p_id and plug-in p_id so the ml plug-in can check things as needed
	_customAllowed = FALSE;

	MLSKINWINDOW l_ml_skin_window = { 0 };
	l_ml_skin_window.skinType   = SKINNEDWND_TYPE_DIALOG;
	l_ml_skin_window.style      = SWS_USESKINCOLORS | SWS_USESKINCURSORS | SWS_USESKINFONT;
	l_ml_skin_window.hwndToSkin = p_hwndDlg;

	MLSkinWindow( g_plugin.hwndLibraryParent, &l_ml_skin_window );


	ShellExecuteW( NULL, L"open", FANZONE_BASE_URL, NULL, NULL, SW_SHOWNORMAL );

	//delete g_wa_config;

	SetTimer( p_hwndDlg, 100, 15, NULL );


	return TRUE;
}


INT_PTR CALLBACK viewDialogProc( HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	INT_PTR a = dialogSkinner.Handle( hwndDlg, uMsg, wParam, lParam );
	if ( a )
		return a;

	switch ( uMsg )
	{
		HANDLE_MSG( hwndDlg, WM_INITDIALOG, plugin_OnInitDialog );
		HANDLE_MSG( hwndDlg, WM_COMMAND,    plugin_OnCommand );
		HANDLE_MSG( hwndDlg, WM_DESTROY,    plugin_OnDestroy );

		case WM_WINDOWPOSCHANGED:
			if ( ( SWP_NOSIZE | SWP_NOMOVE ) != ( ( SWP_NOSIZE | SWP_NOMOVE ) & ( (WINDOWPOS *)lParam )->flags ) ||
				 ( SWP_FRAMECHANGED & ( (WINDOWPOS *)lParam )->flags ) )
			{
				LayoutWindows( hwndDlg, !( SWP_NOREDRAW & ( (WINDOWPOS *)lParam )->flags ) );
			}
			return 0;

		case WM_USER + 0x200:
			SetWindowLongPtr( hwndDlg, DWLP_MSGRESULT, 1 ); // yes, we support no - redraw resize
			return TRUE;

		case WM_USER + 0x201:
			offsetX     = (short)LOWORD( wParam );
			offsetY     = (short)HIWORD( wParam );
			g_rgnUpdate = (HRGN)lParam;
			return TRUE;

		case WM_PAINT:
		{
			int tab[] = { IDC_LIST_FANZONE | DCW_SUNKENBORDER };
			dialogSkinner.Draw( hwndDlg, tab, sizeof( tab ) / sizeof( tab[ 0 ] ) );
		}
		return 0;

		case WM_INITMENUPOPUP:
			if ( wParam && (HMENU)wParam == _sendToMenu.build_hMenu && _sendToMenu.mode == 1 )
			{
				if ( SendMessage( g_plugin.hwndWinampParent, WM_WA_IPC, (WPARAM)&_sendToMenu, IPC_LIBRARY_SENDTOMENU ) == 0xffffffff )
					_sendToMenu.mode = 2;
			}
			return 0;

		case WM_DISPLAYCHANGE:
			return plugin_OnDisplayChange();

		case WM_NOTIFY:
			return plugin_OnNotify( hwndDlg, (LPNMHDR)lParam );
	}

	return FALSE;
}
