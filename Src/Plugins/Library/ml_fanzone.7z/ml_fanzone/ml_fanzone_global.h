#pragma once

#include <QtCore/qglobal.h>

#ifndef BUILD_STATIC
# if defined(ML_FANZONE_LIB)
#  define ML_FANZONE_EXPORT Q_DECL_EXPORT
# else
#  define ML_FANZONE_EXPORT Q_DECL_IMPORT
# endif
#else
# define ML_FANZONE_EXPORT
#endif
