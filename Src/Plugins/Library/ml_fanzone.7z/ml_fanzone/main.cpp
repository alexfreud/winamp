#define PLUGIN_VERSION L"0.1"


#include <strsafe.h>

#include "main.h"

#include "../nu/AutoWide.h"

#include "../../General/gen_ml/menu.h"
#include "../../General/gen_ml/ml_ipc_0313.h"

#include "../WAT/WAT.h"

static int  Init();
static void Quit();

extern "C" winampMediaLibraryPlugin g_plugin =
{
	MLHDR_VER,
	"nullsoft(ml_fanzone.dll)",
	Init,
	Quit,
	pluginMessageProc,
	0,
	0,
	0,
};

int       g_treeItem = 0;

HCURSOR   g_hDragNDropCursor;
C_Config *g_config  = Q_NULLPTR;

WNDPROC   _waProc   = 0;

// wasabi based services for localisation support
api_language    *WASABI_API_LNG        = Q_NULLPTR;
HINSTANCE        WASABI_API_LNG_HINST  = 0;
HINSTANCE        WASABI_API_ORIG_HINST = 0;
api_stats       *AGAVE_API_STATS       = Q_NULLPTR;
api_application *WASABI_API_APP        = Q_NULLPTR;

static DWORD WINAPI wa_newWndProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	if ( _waProc )
		return (DWORD)CallWindowProcW( _waProc, hwnd, msg, wParam, lParam );
	else
		return (DWORD)DefWindowProc( hwnd, msg, wParam, lParam );
}

int Init()
{
	_waProc = (WNDPROC)SetWindowLongPtrW( g_plugin.hwndWinampParent, GWLP_WNDPROC, (LONG_PTR)wa_newWndProc );

	mediaLibrary.library  = g_plugin.hwndLibraryParent;
	mediaLibrary.winamp   = g_plugin.hwndWinampParent;
	mediaLibrary.instance = g_plugin.hDllInstance;

	waServiceFactory *l_wa_service_factory = g_plugin.service->service_getServiceByGuid( languageApiGUID );
	if ( l_wa_service_factory )
		WASABI_API_LNG = reinterpret_cast<api_language *>( l_wa_service_factory->getInterface() );

	l_wa_service_factory = g_plugin.service->service_getServiceByGuid( AnonymousStatsGUID );
	if ( l_wa_service_factory )
		AGAVE_API_STATS = reinterpret_cast<api_stats *>( l_wa_service_factory->getInterface() );

	l_wa_service_factory = g_plugin.service->service_getServiceByGuid( applicationApiServiceGuid );
	if ( l_wa_service_factory )
		WASABI_API_APP = reinterpret_cast<api_application *>( l_wa_service_factory->getInterface() );

	// need to have this initialised before we try to do anything with localisation features
	WASABI_API_START_LANG( g_plugin.hDllInstance, MlFanZoneLangGUID );

	static wchar_t l_plugin_description[ 256 ];
	StringCchPrintfW( l_plugin_description, ARRAYSIZE( l_plugin_description ), WASABI_API_LNGSTRINGW( IDS_NULLSOFT_FANZONE ), PLUGIN_VERSION );
	g_plugin.description = (char *)l_plugin_description;

	wchar_t l_ini_file[ MAX_PATH ] = { 0 };
	mediaLibrary.BuildPath( L"Plugins", l_ini_file, MAX_PATH );

	CreateDirectoryW( l_ini_file, NULL );

	mediaLibrary.BuildPath( L"Plugins\\gen_ml.ini", l_ini_file, MAX_PATH );
	g_config = new C_Config( l_ini_file );


	g_hDragNDropCursor = LoadCursor( GetModuleHandle( L"gen_ml.dll" ), MAKEINTRESOURCE( ML_IDC_DRAGDROP ) );

	NAVINSERTSTRUCT l_nav_insert_struct = { 0 };
	l_nav_insert_struct.item.cbSize         = sizeof( NAVITEM );
	l_nav_insert_struct.item.pszText        = WASABI_API_LNGSTRINGW( IDS_FANZONE );
	l_nav_insert_struct.item.pszInvariant   = _wcsdup( L"FanZone Library" );
	l_nav_insert_struct.item.mask           = NIMF_TEXT | NIMF_TEXTINVARIANT | NIMF_IMAGE | NIMF_IMAGESEL;
	l_nav_insert_struct.item.iSelectedImage = l_nav_insert_struct.item.iImage = mediaLibrary.AddTreeImageBmp( IDB_TREEITEM_FANZONE );

	// map to item id (will probably have to change but is a quick port to support invariant item naming)
	NAVITEM l_nav_item = { sizeof( NAVITEM ), 0, NIMF_ITEMID, };
	l_nav_item.hItem = MLNavCtrl_InsertItem( g_plugin.hwndLibraryParent, &l_nav_insert_struct );
	MLNavItem_GetInfo( g_plugin.hwndLibraryParent, &l_nav_item );
	g_treeItem = l_nav_item.id;


	return 0;
}

void Quit()
{
	if ( g_config != Q_NULLPTR )
		delete g_config;
}

extern "C" __declspec( dllexport ) winampMediaLibraryPlugin * winampGetMediaLibraryPlugin()
{
	return &g_plugin;
}