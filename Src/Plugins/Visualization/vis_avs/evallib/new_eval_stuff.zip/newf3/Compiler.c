#include <windows.h>
#include <stdio.h>
#include <math.h>
#include "Compiler.h"
#include "eval.h"

//fucko: document exec2() and assign() :)

#define LLB_DSIZE (65536-64)
typedef struct _llBlock {
	struct _llBlock *next;
  int sizeused;
	char block[LLB_DSIZE];
} llBlock;

typedef struct _startPtr {
  struct _startPtr *next;
  void *startptr;
} startPtr;

typedef struct {
	llBlock *blocks;
  void *code;
} codeHandleType;

static llBlock *blocks_head = NULL;
static llBlock *tmpblocks_head = NULL; // used only during compile

double computTable[16384];
double *nextBlock=computTable;

extern CRITICAL_SECTION g_eval_cs;

static void *newBlock(int size);
static void *newTmpBlock(int size);
static void freeBlocks(llBlock *start);


char *g_visdata;

void _asm_sin(void);
void _asm_cos(void);
void _asm_tan(void);
void _asm_asin(void);
void _asm_acos(void);
void _asm_atan(void);
void _asm_atan2(void);
void _asm_sqr(void);
void _asm_sqrt(void);
void _asm_pow(void);
void _asm_exp(void);
void _asm_log(void);
void _asm_log10(void);
void _asm_abs(void);
void _asm_min(void);
void _asm_max(void);
void _asm_sig(void);
void _asm_sign(void);
void _asm_rand(void);
void _asm_band(void);
void _asm_bor(void);
void _asm_bnot(void);
void _asm_if(void);
void _asm_equal(void);
void _asm_below(void);
void _asm_above(void);
void _asm_assign(void);
void _asm_add(void);
void _asm_sub(void);
void _asm_mul(void);
void _asm_div(void);
void _asm_mod(void);
void _asm_or(void);
void _asm_and(void);
void _asm_uplus(void);
void _asm_uminus(void);
void _asm_getosc(void);
void _asm_getspec(void);
void _asm_gettime(void);
void _asm_floor(void);
void _asm_ceil(void);
void _asm_invsqrt(void);
void _asm_exec2(void);


void _asm_sin_end(void);
void _asm_cos_end(void);
void _asm_tan_end(void);
void _asm_asin_end(void);
void _asm_acos_end(void);
void _asm_atan_end(void);
void _asm_atan2_end(void);
void _asm_sqr_end(void);
void _asm_sqrt_end(void);
void _asm_pow_end(void);
void _asm_exp_end(void);
void _asm_log_end(void);
void _asm_log10_end(void);
void _asm_abs_end(void);
void _asm_min_end(void);
void _asm_max_end(void);
void _asm_sig_end(void);
void _asm_sign_end(void);
void _asm_rand_end(void);
void _asm_band_end(void);
void _asm_bor_end(void);
void _asm_bnot_end(void);
void _asm_if_end(void);
void _asm_equal_end(void);
void _asm_below_end(void);
void _asm_above_end(void);
void _asm_assign_end(void);
void _asm_add_end(void);
void _asm_sub_end(void);
void _asm_mul_end(void);
void _asm_div_end(void);
void _asm_mod_end(void);
void _asm_or_end(void);
void _asm_and_end(void);
void _asm_uplus_end(void);
void _asm_uminus_end(void);
void _asm_getosc_end(void);
void _asm_getspec_end(void);
void _asm_gettime_end(void);
void _asm_floor_end(void);
void _asm_ceil_end(void);
void _asm_invsqrt_end(void);
void _asm_exec2_end(void);



void _asm_function3(void);
void _asm_function3_end(void);
void _asm_function2(void);
void _asm_function2_end(void);
void _asm_function1(void);
void _asm_function1_end(void);
void _asm_simpleValue(void);
void _asm_simpleValue_end(void);


void _asm_resetcomputable(void);
void _asm_resetcomputable_end(void);

functionType fnTable[34] = {
													 { "if",     _asm_if,_asm_if_end,    3 },
                           { "sin",   _asm_sin,_asm_sin_end,   1 },
                           { "cos",    _asm_cos,_asm_cos_end,   1 },
                           { "tan",    _asm_tan,_asm_tan_end,   1 },
                           { "asin",   _asm_asin,_asm_asin_end,  1 },
                           { "acos",   _asm_acos,_asm_acos_end,  1 },
                           { "atan",   _asm_atan,_asm_atan_end,  1 },
                           { "atan2",  _asm_atan2,_asm_atan2_end, 2 },
                           { "sqr",    _asm_sqr,_asm_sqr_end,   1 },
                           { "sqrt",   _asm_sqrt,_asm_sqrt_end,  1 },
                           { "pow",    _asm_pow,_asm_pow_end,   2 },
                           { "exp",    _asm_exp,_asm_exp_end,   1 },
                           { "log",    _asm_log,_asm_log_end,   1 },
                           { "log10",  _asm_log10,_asm_log10_end, 1 },
                           { "abs",    _asm_abs,_asm_abs_end,   1 },
                           { "min",    _asm_min,_asm_min_end,   2 },
                           { "max",    _asm_max,_asm_max_end,   2 },
													 { "sigmoid",_asm_sig,_asm_sig_end,   2 } ,
													 { "sign",   _asm_sign,_asm_sign_end,  1 } ,
													 { "rand",   _asm_rand,_asm_rand_end,  1 } ,
													 { "band",   _asm_band,_asm_band_end,  2 } ,
													 { "bor",    _asm_bor,_asm_bor_end,   2 } ,
													 { "bnot",   _asm_bnot,_asm_bnot_end,  1 } ,
													 { "equal",  _asm_equal,_asm_equal_end, 2 },
													 { "below",  _asm_below,_asm_below_end, 2 },
													 { "above",  _asm_above,_asm_above_end, 2 },
													 { "getosc", _asm_getosc,_asm_getosc_end,3 },
													 { "getspec",_asm_getspec,_asm_getspec_end,3 },
                           { "gettime", _asm_gettime,_asm_gettime_end,1},
                           { "floor",  _asm_floor,_asm_floor_end, 1 },
                           { "ceil",   _asm_ceil,_asm_ceil_end,  1 },
                           { "invsqrt",   _asm_invsqrt,_asm_invsqrt_end,  1 },
                           { "assign",_asm_assign,_asm_assign_end,2},
                           { "exec2",_asm_exec2,_asm_exec2_end,2},
                           };


//---------------------------------------------------------------------------------------------------------------
static void *realAddress(void *fn, void *fn_e, int *size)
{
#ifdef _DEBUG
	// Debug Mode
  *siiiize=0; // fucko, need to figure this out
char *ptr = (char *)fn;
return ptr + (*(int *)(ptr+1))+5;
#else
  // Release Mode
  *size  = (int)fn_e - (int) fn;
	return fn;
#endif
}

//---------------------------------------------------------------------------------------------------------------
static void freeBlocks(llBlock *start)
{
  while (start)
	{
    llBlock *llB = start->next;
    GlobalFree(start);
	  start=llB;
	}
}

//---------------------------------------------------------------------------------------------------------------
static void *newBlock(int size)
{
//  static int total_cnt, total_size, total_blks;
  llBlock *llb;
  int alloc_size;
//  total_cnt++;
//  total_size+=size;
  if (blocks_head && (LLB_DSIZE - blocks_head->sizeused) >= size)
  {
    void *t=blocks_head->block+blocks_head->sizeused;
    blocks_head->sizeused+=size;
//    {
//      char buf[128];
//      wsprintf(buf,"b2: %d chunks, %d bytes, %d blks\n",total_cnt,total_size,total_blks);
//      OutputDebugString(buf);
//    }
    return t;
  }
//  total_blks++;
//    {
//      char buf[128];
//      wsprintf(buf,"bnew: %d chunks, %d bytes, %d blks\n",total_cnt,total_size,total_blks);
//      OutputDebugString(buf);
//    }

  alloc_size=sizeof(llBlock);
  if ((int)size > LLB_DSIZE) alloc_size += size - LLB_DSIZE;
  llb = (llBlock *)GlobalAlloc(GMEM_FIXED,alloc_size); // grab bigger block if absolutely necessary (heh)
  llb->sizeused=size;
  llb->next = blocks_head;  
  blocks_head = llb;
  return llb->block;
}

static void *newTmpBlock(int size)
{
//  static int total_cnt, total_size, total_blks;
  llBlock *llb;
  int alloc_size;
//  total_cnt++;
//  total_size+=size;
  if (tmpblocks_head && (LLB_DSIZE - tmpblocks_head->sizeused) >= size)
  {
    void *t=tmpblocks_head->block+tmpblocks_head->sizeused;
    tmpblocks_head->sizeused+=size;
//    {
//      char buf[128];
//      wsprintf(buf,"b2: %d chunks, %d bytes, %d blks\n",total_cnt,total_size,total_blks);
//      OutputDebugString(buf);
//    }
    return t;
  }
//  total_blks++;
//    {
//      char buf[128];
//      wsprintf(buf,"bnew: %d chunks, %d bytes, %d blks\n",total_cnt,total_size,total_blks);
//      OutputDebugString(buf);
//    }

  alloc_size=sizeof(llBlock);
  if ((int)size > LLB_DSIZE) alloc_size += size - LLB_DSIZE;
  llb = (llBlock *)GlobalAlloc(GMEM_FIXED,alloc_size); // grab bigger block if absolutely necessary (heh)
  llb->sizeused=size;
  llb->next = tmpblocks_head;  
  tmpblocks_head = llb;
  return llb->block;
}

//---------------------------------------------------------------------------------------------------------------
static int *findFBlock(char *p)
{
  while (*(int *)p != 0xFFFFFFFF) p++;
  return (int*)p;
}


//---------------------------------------------------------------------------------------------------------------
int createCompiledValue(double value, double *addrValue)
{
  int size;
  char *block;
  double *dupValue;

  void *p=realAddress(_asm_simpleValue,_asm_simpleValue_end,&size);

  block=(char *)newTmpBlock(size+4);

  if (addrValue == NULL)
	  *(dupValue = (double *)newBlock(sizeof(double))) = value;
  else
	  dupValue = addrValue;

  ((int*)block)[0]=size;
  memcpy(block+4, p, size);

  *findFBlock(block)=(int)dupValue;

  return ((int)(block));

}

//---------------------------------------------------------------------------------------------------------------
int getFunctionAddress(int fntype, int fn, int *size)
{
  switch (fntype)
	{
  	case MATH_SIMPLE:
	  	switch (fn)
			{
			  case FN_ASSIGN:
				  return (int)realAddress(_asm_assign,_asm_assign_end,size);
			  case FN_ADD:
				  return (int)realAddress(_asm_add,_asm_add_end,size);
			  case FN_SUB:
				  return (int)realAddress(_asm_sub,_asm_sub_end,size);
			  case FN_MULTIPLY:
				  return (int)realAddress(_asm_mul,_asm_mul_end,size);
			  case FN_DIVIDE:
				  return (int)realAddress(_asm_div,_asm_div_end,size);
			  case FN_MODULO:
				  return (int)realAddress(_asm_mod,_asm_mod_end,size);
			  case FN_AND:
				  return (int)realAddress(_asm_and,_asm_and_end,size);
			  case FN_OR:
				  return (int)realAddress(_asm_or,_asm_or_end,size);
			  case FN_UPLUS:
				  return (int)realAddress(_asm_uplus,_asm_uplus_end,size);
			  case FN_UMINUS:
				  return (int)realAddress(_asm_uminus,_asm_uminus_end,size);
			}
	  case MATH_FN:
		  return (int)realAddress(fnTable[fn].afunc,fnTable[fn].func_e,size);
	}		
  return 0;
}


//---------------------------------------------------------------------------------------------------------------
int createCompiledFunction3(int fntype, int fn, int code1, int code2, int code3)
{
  int sizes1=((int *)code1)[0];
  int sizes2=((int *)code2)[0];
  int sizes3=((int *)code3)[0];
  void *func3;
  int size;

  if (fntype == MATH_FN && fn == 0) // special case: IF
  {
    int *ptr;
    char *block;

    unsigned char *newblock2,*newblock3;

    newblock2=newBlock(sizes2+1);
    memcpy(newblock2,(char*)code2+4,sizes2);
    newblock2[sizes2]=0xC3;

    newblock3=newBlock(sizes3+1);
    memcpy(newblock3,(char*)code3+4,sizes3);
    newblock3[sizes3]=0xC3;
    
    func3 = realAddress(_asm_if,_asm_if_end,&size);

    block=(char *)newTmpBlock(4+sizes1+size);
    ((int*)block)[0]=sizes1+size;
    memcpy(block+4,(char*)code1+4,sizes1);
    ptr=(int *)(block+4+sizes1);
    memcpy(ptr,func3,size);

    ptr=findFBlock((char*)ptr); *ptr++=(int)newblock2;
    ptr=findFBlock((char*)ptr); *ptr++=(int)newblock3;

    return (int)block;

  }
  else
  {
    int size2;
    char *block;
    int myfunc;

    func3 = realAddress(_asm_function3,_asm_function3_end,&size);
    myfunc = getFunctionAddress(fntype, fn, &size2);

    block=(char *)newTmpBlock(size+size2+sizes1+sizes2+sizes3-12+4);
    ((int*)block)[0]=size+size2+sizes1+sizes2+sizes3-12;

    {
      char *inp=(char*)func3;
      char *outp=block+4;
      int l=size;
      int cnt=0;
      while (l>0)
      {
        if (((int*)inp)[0] == 0xFFFFFFFF)
        {
          if (cnt == 0) { memcpy(outp,(char*)code1+4,sizes1); outp+=sizes1; }
          if (cnt == 1) { memcpy(outp,(char*)code2+4,sizes2); outp+=sizes2; }
          if (cnt == 2) { memcpy(outp,(char*)code3+4,sizes3); outp+=sizes3; }
          cnt++;
          inp+=4;
          l-=4;
        }
        else
        {
          *outp++=*inp++;
          l--;
        }
      }
    }
    memcpy(block+4+size+sizes1+sizes2+sizes3-12,(void*)myfunc,size2);

    return ((int)(block));
  }
}

//---------------------------------------------------------------------------------------------------------------
int createCompiledFunction2(int fntype, int fn, int code1, int code2)
{
  int size,size2;
  char *block;
  int myfunc;
  void *func3;
  int sizes1=((int *)code1)[0];
  int sizes2=((int *)code2)[0];

  func3 = realAddress(_asm_function2,_asm_function2_end,&size);
  myfunc = getFunctionAddress(fntype, fn, &size2);

  block=(char *)newTmpBlock(size+size2+sizes1+sizes2-8+4);

  ((int*)block)[0]=size+size2+sizes1+sizes2-8;
  {
    char *inp=(char*)func3;
    char *outp=block+4;
    int l=size;
    int cnt=0;
    while (l>0)
    {
      if (((int*)inp)[0] == 0xFFFFFFFF)
      {
        if (cnt == 0) { memcpy(outp,(char*)code1+4,sizes1); outp+=sizes1; }
        if (cnt == 1) { memcpy(outp,(char*)code2+4,sizes2); outp+=sizes2; }
        cnt++;
        inp+=4;
        l-=4;
      }
      else
      {
        *outp++=*inp++;
        l--;
      }
    }
  }
  memcpy(block+4+size+sizes1+sizes2-8,(void*)myfunc,size2);

  return ((int)(block));

}


//---------------------------------------------------------------------------------------------------------------
int createCompiledFunction1(int fntype, int fn, int code)
{
  int size,size2;
  char *block;
  int myfunc;
  void *func1;
  
  size =((int *)code)[0];
  func1 = (void *)(code+4);

  myfunc = getFunctionAddress(fntype, fn, &size2);

  block=(char *)newTmpBlock(4+size+size2);
  ((int*)block)[0]=size+size2;

  memcpy(block+4, func1, size);
  memcpy(block+size+4,(void*)myfunc,size2);

  return ((int)(block));
}

static char *preprocessCode(char *expression)
{
  int len=0;
  int alloc_len=strlen(expression)+1+64;
  char *buf=(char *)malloc(alloc_len);

  while (*expression)
  {
    if (len > alloc_len-32)
    {
      alloc_len = len+128;
      buf=(char*)realloc(buf,alloc_len);
    }

    if (expression[0] == '/')
    {
      if (expression[1] == '/')
      {
        expression+=2;
        while (expression[0] && expression[0] != '\r' && expression[0] != '\n') expression++;
      }
      else if (expression[1] == '*')
      {
        expression+=2;
        while (expression[0] && (expression[0] != '*' || expression[1] != '/')) expression++;
        if (expression[0]) expression+=2; // at this point we KNOW expression[0]=* and expression[1]=/
      }
      else buf[len++]=*expression++;
    }
    else if (expression[0] == '$')
    {
      if (toupper(expression[1]) == 'P' && toupper(expression[2]) == 'I')
      {
        static char *str="3.141592653589793";
        expression+=3;
        memcpy(buf+len,str,17);
        len+=17; //strlen(str);
      }
      else if (toupper(expression[1]) == 'E')
      {
        static char *str="2.71828183";
        expression+=2;
        memcpy(buf+len,str,10);
        len+=10; //strlen(str);
      }
      if (toupper(expression[1]) == 'P' && toupper(expression[2]) == 'H' && toupper(expression[3]) == 'I')
      {
        static char *str="1.61803399";
        expression+=4;
        memcpy(buf+len,str,10);
        len+=10; //strlen(str);
      }
      else buf[len++]=*expression++;
    }
    else
    {
      char c=*expression++;
      if (c == '\r' || c == '\n' || c == '\t') c=' ';
      buf[len++]=c;
    }
  }
  buf[len]=0;

  return buf;
}

int g_log_errors;

static void movestringover(char *str, int amount)
{
  char tmp[1024+8];

  int l=(int)strlen(str);
  l=min(1024-amount-1,l);

  memcpy(tmp,str,l+1);

  while (l >= 0 && tmp[l]!='\n') l--;
  l++;

  tmp[l]=0;//ensure we null terminate

  memcpy(str+amount,tmp,l+1);
}

//------------------------------------------------------------------------------
int compileCode(char *_expression)
{
  char *expression,*expression_start;
  codeHandleType *handle;
  startPtr *scode=NULL;
  startPtr *startpts=NULL;

  if (!_expression || !*_expression) return 0;
  if (!varTable) return 0;

  EnterCriticalSection(&g_eval_cs);

  blocks_head=0;
  tmpblocks_head=0;

  handle = (codeHandleType*)newBlock(sizeof(codeHandleType));

  if (!handle) 
  {
    LeaveCriticalSection(&g_eval_cs);
    return 0;
  }
  
  memset(handle,0,sizeof(codeHandleType));

  expression_start=expression=preprocessCode(_expression);

  while (*expression)
	{
    startPtr *tmp;
    char *expr;
    colCount=0;

    // single out segment
    while (*expression == ';' || *expression == ' ') expression++;
    if (!*expression) break;
    expr=expression;
	  while (*expression && *expression != ';') expression++;
    if (*expression) *expression++ = 0;

    // parse
    tmp=(startPtr*) newTmpBlock(sizeof(startPtr));
    if (!tmp) break;
    tmp->startptr=compileExpression(expr);
    if (!tmp->startptr) 
    { 
      if (g_log_errors)
      {
        int l=strlen(expr);
        movestringover(last_error_string,l+2);
        memcpy(last_error_string,expr,l);
        last_error_string[l]='\r';
        last_error_string[l+1]='\n';
      }

      scode=NULL; 
      break; 
    }
    tmp->next=NULL;
    if (!scode) scode=startpts=tmp;
    else
    {
      scode->next=tmp;
      scode=tmp;
    }
  }

  // check to see if failed on the first startingCode
  if (!scode)
  {
    freeBlocks(blocks_head);  // free blocks
    handle=NULL;              // return NULL (after resetting blocks_head)
  }
  else 
  {
    // now we build one big code segment out of our list of them, inserting _asm_resetcomputable before each item
    int rct_size;
    void *rct=realAddress(_asm_resetcomputable, _asm_resetcomputable_end, &rct_size);
    unsigned char *writeptr;
    int size=1; // for ret at end :)
    startPtr *p;
    p=startpts;
    while (p)
    {
      size+=*(int *)p->startptr;
      size+=rct_size;
      p=p->next;
    }
    handle->code = newBlock(size);
    if (handle->code)
    {
      writeptr=(unsigned char *)handle->code;
      p=startpts;
      while (p)
      {
        int thissize=*(int *)p->startptr;
        memcpy(writeptr,rct,rct_size);
        writeptr+=rct_size;
        memcpy(writeptr,(char*)p->startptr + 4,thissize);
        writeptr += thissize;
      
        p=p->next;
      }
      *writeptr=0xC3; // ret
#if 0
      {
        char buf[512];
        wsprintf(buf,"Compiled expressions to %d of x86 code!\n",size);
        OutputDebugString(buf);
      }
#endif
    }
    handle->blocks = blocks_head;
  }
  freeBlocks(tmpblocks_head);  // free blocks
  tmpblocks_head=0;

  blocks_head=0;

  LeaveCriticalSection(&g_eval_cs);

  free(expression_start);

  return (int)handle;
}

//------------------------------------------------------------------------------
void executeCode(int handle, char visdata[2][2][576])
{
  codeHandleType *h = (codeHandleType *)handle;
  if (!h || !h->code) return;
  EnterCriticalSection(&g_eval_cs);
  g_visdata=(char*)visdata;
  {
    int startPoint=(int)h->code;
    __asm pusha // Lets cover our ass
    __asm call startPoint
    __asm popa
  }
  g_visdata=NULL;
  LeaveCriticalSection(&g_eval_cs);
}

//------------------------------------------------------------------------------
void freeCode(int handle)
{
  codeHandleType *h = (codeHandleType *)handle;
  if (h != NULL)
  {
    freeBlocks(h->blocks);
  }
}


static double getvis(unsigned char *visdata, int bc, int bw, int ch, int xorv)
{
  int x;
  int accum=0;
  if (ch && ch != 1 && ch != 2) return 0.0;

  if (bw < 1) bw=1;
  bc-=bw/2;
  if (bc < 0) 
  {
    bw+=bc;
    bc=0;
  }
  if (bc > 575) bc=575;
  if (bc+bw > 576) bw=576-bc;


  if (!ch)
  {
    for (x = 0; x < bw; x ++) 
    {
      accum+=(visdata[bc]^xorv)-xorv;
      accum+=(visdata[bc+576]^xorv)-xorv;
      bc++;
    }
    return (double)accum / ((double)bw*255.0);
  }
  else 
  {
    if (ch == 2) visdata+=576;
    for (x = 0; x < bw; x ++) accum+=(visdata[bc++]^xorv)-xorv;
    return (double)accum / ((double)bw*127.5);
  }
}

double getosc(double band, double bandw, double chan)
{
  if (!g_visdata) return 0.0;
  return getvis((unsigned char *)g_visdata+576*2,(int)(band*576.0),(int)(bandw*576.0),(int)(chan+0.5),128);
}
double getspec(double band, double bandw, double chan)
{
  if (!g_visdata) return 0.0;
  return getvis((unsigned char *)g_visdata,(int)(band*576.0),(int)(bandw*576.0),(int)(chan+0.5),0)*0.5;
}
