#include <windows.h>
#include <stdio.h>
#include <math.h>
#include "Compiler.h"
#include "eval.h"


static float g_cmpaddtab[2]={0.0,1.0};
static double g_closefact = 0.00001, g_half=0.5;
extern double *nextBlock;


extern double computTable[16384];
extern double *nextBlock;

__declspec ( naked ) void _asm_resetcomputable(void)
{
  __asm 
  {
    mov eax, offset computTable
    mov [nextBlock], eax
  }
}
__declspec ( naked ) void _asm_resetcomputable_end(void){}


// FUNCTION CALL TEMPLATES - THESE ARE NEVER ACTUALLY CALLED,
// BUT COPIED AND MODIFIED.
//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_simpleValue(void)
{
  __asm 
  {
    mov eax, 0FFFFFFFFh;
  }
}
__declspec ( naked ) void _asm_simpleValue_end(void){}


//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_function3(void)
{
  __asm 
  {
    __emit 0xFF
    __emit 0xFF
    __emit 0xFF
    __emit 0xFF
    push eax
    __emit 0xFF
    __emit 0xFF
    __emit 0xFF
    __emit 0xFF
    push eax
    __emit 0xFF
    __emit 0xFF
    __emit 0xFF
    __emit 0xFF
    pop ebx
    pop ecx
  }
}
__declspec ( naked ) void _asm_function3_end(void){}


//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_function2(void)
{
  __asm 
  {
    __emit 0xFF
    __emit 0xFF
    __emit 0xFF
    __emit 0xFF
    push eax
    __emit 0xFF
    __emit 0xFF
    __emit 0xFF
    __emit 0xFF
    pop ebx
  }                      
}
__declspec ( naked ) void _asm_function2_end(void){}

// END FUNCTION CALL TEMPLATES



// our registers
static int a,b,c;
static double *res;


#define isnonzero(x) (fabs(x) > g_closefact)

//---------------------------------------------------------------------------------------------------------------
static double _rand(double x)
{
  if (x < 1.0) x=1.0;
  return (double)(rand()%(int)max(x,1.0));
}

//---------------------------------------------------------------------------------------------------------------
static double _band(double var, double var2)
{
return isnonzero(var) && isnonzero(var2) ? 1 : 0;
}

//---------------------------------------------------------------------------------------------------------------
static double _bor(double var, double var2)
{
return isnonzero(var) || isnonzero(var2) ? 1 : 0;
}

//---------------------------------------------------------------------------------------------------------------
static double _sig(double x, double constraint)
{
double t = (1+exp(-x*constraint));
return isnonzero(t) ? 1.0/t : 0;
}

extern char *g_visdata;

static double getvis(unsigned char *visdata, int bc, int bw, int ch, int xorv)
{
  int x;
  int accum=0;
  if (ch && ch != 1 && ch != 2) return 0.0;

  if (bw < 1) bw=1;
  bc-=bw/2;
  if (bc < 0) 
  {
    bw+=bc;
    bc=0;
  }
  if (bc > 575) bc=575;
  if (bc+bw > 576) bw=576-bc;


  if (!ch)
  {
    for (x = 0; x < bw; x ++) 
    {
      accum+=(visdata[bc]^xorv)-xorv;
      accum+=(visdata[bc+576]^xorv)-xorv;
      bc++;
    }
    return (double)accum / ((double)bw*255.0);
  }
  else 
  {
    if (ch == 2) visdata+=576;
    for (x = 0; x < bw; x ++) accum+=(visdata[bc++]^xorv)-xorv;
    return (double)accum / ((double)bw*127.5);
  }
}

static double getspec_(double band, double bandw, double chan)
{
  if (!g_visdata) return 0.0;
  return getvis((unsigned char *)g_visdata,(int)(band*576.0),(int)(bandw*576.0),(int)(chan+0.5),0)*0.5;
}

static double getosc_(double band, double bandw, double chan)
{
  if (!g_visdata) return 0.0;
  return getvis((unsigned char *)g_visdata+576*2,(int)(band*576.0),(int)(bandw*576.0),(int)(chan+0.5),128);
}

static double gettime_(double sc)
{
  return GetTickCount()/1000.0 - sc;
}
static double (*__getspec)(double,double,double) = &getspec_;
static double (*__getosc)(double,double,double) = &getosc_;
static double (*__gettime)(double) = &gettime_;


static double (*__asin)(double) = &asin;
//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_asin(void)
{
  __asm mov dword ptr a, eax

  res = nextBlock++;

  *res = __asin(*(double*)a);
  __asm 
  {
    mov eax, res
  }
}
__declspec ( naked ) void _asm_asin_end(void) {}

static double (*__acos)(double) = &acos;
//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_acos(void)
{
  __asm mov dword ptr a, eax

  res = nextBlock++;

  *res = __acos(*(double*)a);
  __asm 
  {
    mov eax, res
  }
}
__declspec ( naked ) void _asm_acos_end(void) {}

//---------------------------------------------------------------------------------------------------------------
static double (*__atan)(double) = &atan;
__declspec ( naked ) void _asm_atan(void)
{
  __asm mov dword ptr a, eax

  res = nextBlock++;

  *res = __atan(*(double*)a);
  __asm 
  {
    mov eax, res
  }
}
__declspec ( naked ) void _asm_atan_end(void) {}

//---------------------------------------------------------------------------------------------------------------
static double (*__atan2)(double,double) = &atan2;
__declspec ( naked ) void _asm_atan2(void)
{
  __asm 
  {
    mov dword ptr a, eax
    mov dword ptr b, ebx
  }

  res = nextBlock++;
  *res = __atan2(*(double*)b, *(double*)a);
  __asm 
  {
    mov eax, res
  }
}
__declspec ( naked ) void _asm_atan2_end(void) {}


//---------------------------------------------------------------------------------------------------------------
static double (*__sig)(double,double) = &_sig;
__declspec ( naked ) void _asm_sig(void)
{
  __asm 
  {
    mov dword ptr a, eax
    mov dword ptr b, ebx
  }
  res = nextBlock++;
  *res = __sig(*(double*)b, *(double*)a);
  __asm 
  {
    mov eax, dword ptr res
  }
}
__declspec ( naked ) void _asm_sig_end(void) {}

//---------------------------------------------------------------------------------------------------------------
static double (*__rand)(double) = &_rand;
__declspec ( naked ) void _asm_rand(void)
{
  __asm 
  {
    mov dword ptr a, eax
  }

  res = nextBlock++;
  *res = __rand(*(double*)a);

  __asm 
  {
    mov eax, res
  }
}
__declspec ( naked ) void _asm_rand_end(void) {}

//---------------------------------------------------------------------------------------------------------------
static double (*__band)(double,double) = &_band;
__declspec ( naked ) void _asm_band(void)
{
  __asm 
  {
    mov dword ptr a, eax
    mov dword ptr b, ebx
  }

  res = nextBlock++;
  *res = __band(*(double*)b, *(double*)a);
  __asm 
  {
    mov eax, res
  }
}
__declspec ( naked ) void _asm_band_end(void) {}

//---------------------------------------------------------------------------------------------------------------
static double (*__bor)(double,double) = &_bor;
__declspec ( naked ) void _asm_bor(void)
{
  __asm 
  {
    mov dword ptr a, eax
    mov dword ptr b, ebx
  }

  res = nextBlock++;
  *res = __bor(*(double*)b, *(double*)a);
  __asm 
  {
    mov eax, res
  }
}
__declspec ( naked ) void _asm_bor_end(void) {}

//---------------------------------------------------------------------------------------------------------------
static double (*__pow)(double,double) = &pow;
__declspec ( naked ) void _asm_pow(void)
{
  __asm 
  {
    mov dword ptr a, eax
    mov dword ptr b, ebx
  }

  res = nextBlock++;
  *res = __pow(*(double*)b, *(double*)a);
  __asm 
  {
    mov eax, res
  }
}
__declspec ( naked ) void _asm_pow_end(void) {}

//---------------------------------------------------------------------------------------------------------------
static double (*__exp)(double) = &exp;
__declspec ( naked ) void _asm_exp(void)
{
  __asm mov dword ptr a, eax

  res = nextBlock++;

  *res = __exp(*(double*)a);
  __asm 
  {
    mov eax, res
  }
}
__declspec ( naked ) void _asm_exp_end(void) {}

//---------------------------------------------------------------------------------------------------------------
static double (*__floor)(double) = &floor;
__declspec ( naked ) void _asm_floor(void)
{
  __asm mov dword ptr a, eax

  res = nextBlock++;

  *res = __floor(*(double*)a);
  __asm 
  {
    mov eax, res
  }
}
__declspec ( naked ) void _asm_floor_end(void) {}


//---------------------------------------------------------------------------------------------------------------
static double (*__ceil)(double) = &ceil;
__declspec ( naked ) void _asm_ceil(void)
{
  __asm mov dword ptr a, eax

  res = nextBlock++;

  *res = __ceil(*(double*)a);
  __asm 
  {
    mov eax, res
  }
}
__declspec ( naked ) void _asm_ceil_end(void) {}

//---------------------------------------------------------------------------------------------------------------

#if 0

static double invsqrt(double a)
{
  float x=(float)a;

  int i = *(int*)&x;
  i = 0x5f3759df - (i >> 1);
  x = *(float*)&i;

  return (double)x*(1.5 - 0.5*a*(double)x*(double)x);
}

__declspec ( naked ) void _asm_invsqrt(void)
{
  __asm mov dword ptr a, eax

  res = nextBlock++;

  *res = invsqrt(*(double*)a);
  __asm 
  {
    mov eax, res
  }
}

#else

static float negativezeropointfive=-0.5f;
static float onepointfive=1.5f;

__declspec ( naked ) void _asm_invsqrt(void)
{
  __asm 
  {
    fld qword ptr [eax]
    mov eax, nextBlock

    mov edx, 0x5f3759df
    fst dword ptr [eax]
    // floating point stack has input, as does [eax]
    fmul dword ptr [negativezeropointfive]
    mov ecx, [eax]
    sar ecx, 1
    sub edx, ecx
    mov [eax], edx
    
    mov ecx, eax

    // st(0) = input, [eax] has x
    fmul dword ptr [eax]

    fmul dword ptr [eax]
    add ecx, 8

    fadd dword ptr [onepointfive]

    fmul dword ptr [eax]
    mov nextBlock, ecx

    fstp qword ptr [eax]
  }
}
__declspec ( naked ) void _asm_invsqrt_end(void) {}
#endif


// these below are all asm, no loops, radness






//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_sin(void)
{
  __asm 
  {
    fld qword ptr [eax]
    mov eax, nextBlock
    fsin
    fstp qword ptr [eax]
    add eax, 8
    mov nextBlock, eax
    sub eax, 8
  }
}
__declspec ( naked ) void _asm_sin_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_cos(void)
{
  __asm 
  {
    fld qword ptr [eax]
    mov eax, nextBlock
    fcos
    fstp qword ptr [eax]
    add eax, 8
    mov nextBlock, eax
    sub eax, 8
  }
}
__declspec ( naked ) void _asm_cos_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_tan(void)
{
  __asm 
  {
    fld qword ptr [eax]
    mov eax, nextBlock
    fsincos
    fdiv
    fstp qword ptr [eax]
    add eax, 8
    mov nextBlock, eax
    sub eax, 8
  }
}
__declspec ( naked ) void _asm_tan_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_sqr(void)
{
  __asm 
  {
    fld qword ptr [eax]
    fld st(0)
    mov eax, nextBlock
    fmul
    fstp qword ptr [eax]
    add eax, 8
    mov nextBlock, eax
    sub eax, 8
  }
}
__declspec ( naked ) void _asm_sqr_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_sqrt(void)
{
  __asm 
  {
    fld qword ptr [eax]
    mov eax, nextBlock
    fabs
    fsqrt
    fstp qword ptr [eax]
    add eax, 8
    mov nextBlock, eax
    sub eax, 8
  }
}
__declspec ( naked ) void _asm_sqrt_end(void) {}


//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_log(void)
{
  __asm 
  {
    fld1
    fldl2e
    fdiv
    fld qword ptr [eax]
    mov eax, nextBlock
    fyl2x
    fstp qword ptr [eax]
    add eax, 8
    mov nextBlock, eax
    sub eax, 8
  }
}
__declspec ( naked ) void _asm_log_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_log10(void)
{
  __asm 
  {
    fld1
    fldl2t
    fdiv
    fld qword ptr [eax]
    mov eax, nextBlock
    fyl2x
    fstp qword ptr [eax]
    add eax, 8
    mov nextBlock, eax
    sub eax, 8
  }
}
__declspec ( naked ) void _asm_log10_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_abs(void)
{
  __asm 
  {
    fld qword ptr [eax]
    mov eax, nextBlock
    fabs
    fstp qword ptr [eax]
    add eax, 8
    mov nextBlock, eax
    sub eax, 8
  }
}
__declspec ( naked ) void _asm_abs_end(void) {}


//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_assign(void)
{
  __asm 
  {
    mov ecx, [eax]
    mov edx, [eax+4]
    mov [ebx], ecx
    mov [ebx+4], edx
  }
}
__declspec ( naked ) void _asm_assign_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_add(void)
{
  __asm 
  {
    fld qword ptr [eax]
    mov eax, nextBlock
    fld qword ptr [ebx]
    fadd
    fstp qword ptr [eax]
    add eax, 8
    mov nextBlock, eax
    sub eax, 8
  }
}
__declspec ( naked ) void _asm_add_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_sub(void)
{
  __asm 
  {
    fld qword ptr [ebx]
    fld qword ptr [eax]
    mov eax, nextBlock
    fsub
    fstp qword ptr [eax]
    add eax, 8
    mov nextBlock, eax
    sub eax, 8
  }
}
__declspec ( naked ) void _asm_sub_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_mul(void)
{
  __asm 
  {
    fld qword ptr [ebx]
    fld qword ptr [eax]
    mov eax, nextBlock
    fmul
    fstp qword ptr [eax]
    add eax, 8
    mov nextBlock, eax
    sub eax, 8
  }
}
__declspec ( naked ) void _asm_mul_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_div(void)
{
  __asm 
  {
    fld qword ptr [ebx]
    fdiv qword ptr [eax]
    mov eax, nextBlock
    fstp qword ptr [eax]
    add eax, 8
    mov nextBlock, eax
    sub eax, 8
  }
}
__declspec ( naked ) void _asm_div_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_mod(void)
{
  __asm 
  {
    fld qword ptr [ebx]

    fld qword ptr [eax]
    fsub dword ptr [g_cmpaddtab+4]
    fabs
    fadd qword ptr [eax]
    fadd dword ptr [g_cmpaddtab+4]

    fmul qword ptr [g_half]

    mov ebx, nextBlock 

    fistp dword ptr [ebx]
    fistp dword ptr [ebx+4]
    mov eax, [ebx+4]
    xor edx, edx
    div dword ptr [ebx]
    mov [ebx], edx
    fild dword ptr [ebx]
    fstp qword ptr [ebx]
    mov eax, ebx
    add ebx, 8
    mov nextBlock, ebx // eax is still good
  }
}
__declspec ( naked ) void _asm_mod_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_or(void)
{
  __asm 
  {
    fld qword ptr [ebx]
    fld qword ptr [eax]
    mov eax, nextBlock
    fistp qword ptr [eax]
    fistp qword ptr [eax+8]
    mov ebx, [eax+8]
    or [eax], ebx
    mov ebx, [eax+12]
    or [eax+4], ebx
    fild qword ptr [eax]
    fstp qword ptr [eax]
    add eax, 8
    mov nextBlock, eax
    sub eax, 8
  }
}
__declspec ( naked ) void _asm_or_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_and(void)
{
  __asm 
  {
    fld qword ptr [ebx]
    fld qword ptr [eax]
    mov eax, nextBlock
    fistp qword ptr [eax]
    fistp qword ptr [eax+8]
    mov ebx, [eax+8]
    and [eax], ebx
    mov ebx, [eax+12]
    and [eax+4], ebx
    fild qword ptr [eax]
    fstp qword ptr [eax]
    add eax, 8
    mov nextBlock, eax
    sub eax, 8
  }
}
__declspec ( naked ) void _asm_and_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_uplus(void)
{
  __asm 
  {
    mov ebx, nextBlock
    mov ecx, [eax]
    mov [ebx], ecx
    mov ecx, [eax+4]
    mov [ebx+4], ecx
    mov eax, ebx
    add ebx, 8
    mov nextBlock, ebx
  }
}
__declspec ( naked ) void _asm_uplus_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_uminus(void)
{
  __asm 
  {
    mov ebx, nextBlock
    mov ecx, [eax]
    mov [ebx], ecx
    mov ecx, [eax+4]
    xor ecx, 0x80000000
    mov [ebx+4], ecx
    mov eax, ebx
    add ebx, 8
    mov nextBlock, ebx
  }
}
__declspec ( naked ) void _asm_uminus_end(void) {}



//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_sign(void)
{
  __asm
  {
    fld qword ptr [eax]
    fld st(0)
    fabs
    mov eax, nextBlock
    fld qword ptr [g_closefact]
    fadd
    fdiv
    fstp qword ptr [eax]
    add eax, 8
    mov nextBlock, eax
    sub eax, 8
  }
}
__declspec ( naked ) void _asm_sign_end(void) {}



//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_bnot(void)
{
  __asm
  {
    mov ebx, nextBlock
    fld qword ptr [g_closefact]
    fld qword ptr [eax]
    fabs
    fcompp
    fstsw ax
    shr eax, 6
    and eax, (1<<2)
    fld dword ptr [g_cmpaddtab+eax]
    fstp qword ptr [ebx]   
    mov eax, ebx
    add ebx, 8
    mov nextBlock, ebx   
  }
}
__declspec ( naked ) void _asm_bnot_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_if(void)
{
  __asm
  {
    fld qword ptr [eax]
    fld qword ptr [ebx]
    fld qword ptr [g_closefact]
    fld qword ptr [ecx]
    fabs
    fcompp
    fstsw ax
    mov ebx, nextBlock
    fstp qword ptr [ebx]
    fstp qword ptr [ebx+8]
    shr eax, 5
    and eax, (1<<3)
    add eax, ebx
    fld qword ptr [eax]
    fstp qword ptr [ebx]   
    mov eax, ebx
    add ebx, 8
    mov nextBlock, ebx   
  }
}
__declspec ( naked ) void _asm_if_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_equal(vpod)
{
  __asm
  {
    fld qword ptr [g_closefact]
    fld qword ptr [eax]
    fld qword ptr [ebx]
    fsub
    fabs
    fcompp
    fstsw ax
    shr eax, 6
    and eax, (1<<2)
    fld dword ptr [g_cmpaddtab+eax]
    mov eax, nextBlock
    fstp qword ptr [eax]   
    mov ebx, eax
    add ebx, 8
    mov nextBlock, ebx   
  }
}
__declspec ( naked ) void _asm_equal_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_below(void)
{
  __asm
  {
    fld qword ptr [eax]
    fld qword ptr [ebx]
    mov ebx, nextBlock
    fcompp
    fstsw ax
    shr eax, 6
    and eax, (1<<2)
    fld dword ptr [g_cmpaddtab+eax]
    fstp qword ptr [ebx]   
    mov eax, ebx
    add ebx, 8
    mov nextBlock, ebx   
  }
}
__declspec ( naked ) void _asm_below_end(void) {}

//---------------------------------------------------------------------------------------------------------------
__declspec ( naked ) void _asm_above(void)
{
  __asm
  {
    fld qword ptr [ebx]
    fld qword ptr [eax]
    mov ebx, nextBlock
    fcompp
    fstsw ax
    shr eax, 6
    and eax, (1<<2)
    fld dword ptr [g_cmpaddtab+eax]
    fstp qword ptr [ebx]   
    mov eax, ebx
    add ebx, 8
    mov nextBlock, ebx   
  }
}
__declspec ( naked ) void _asm_above_end(void) {}


__declspec ( naked ) void _asm_min(void)
{
  __asm 
  {
    fld qword ptr [eax]
    fld qword ptr [ebx]
    fld st(1)
    mov eax, nextBlock
    fld st(1)
    add eax, 8
    fsub
    mov nextBlock, eax
    fabs  // stack contains fabs(1-2),1,2
    fchs
    sub eax, 8
    fadd
    fadd
    fld qword ptr [g_half]
    fmul
    fstp qword ptr [eax]
  }
}
__declspec ( naked ) void _asm_min_end(void) {}

__declspec ( naked ) void _asm_max(void)
{
  __asm 
  {
    fld qword ptr [eax]
    fld qword ptr [ebx]
    fld st(1)
    mov eax, nextBlock
    fld st(1)
    add eax, 8
    fsub
    mov nextBlock, eax
    fabs  // stack contains fabs(1-2),1,2
    sub eax, 8
    fadd
    fadd
    fld qword ptr [g_half]
    fmul
    fstp qword ptr [eax]
  }
}
__declspec ( naked ) void _asm_max_end(void) {}


__declspec ( naked ) void _asm_getosc(void)
{
  __asm 
  {
    mov dword ptr a, eax
    mov dword ptr b, ebx
    mov dword ptr c, ecx
  }

  res = nextBlock++;
  *res = __getosc(*(double*)c,*(double*)b,*(double*)a);
  __asm 
  {
    mov eax, res
  }
}
__declspec ( naked ) void _asm_getosc_end(void) {}

__declspec ( naked ) void _asm_getspec(void)
{
  __asm 
  {
    mov dword ptr a, eax
    mov dword ptr b, ebx
    mov dword ptr c, ecx
  }

  res = nextBlock++;
  *res = __getspec(*(double*)c,*(double*)b,*(double*)a);
  __asm 
  {
    mov eax, res
  }
}
__declspec ( naked ) void _asm_getspec_end(void) {}

__declspec ( naked ) void _asm_gettime(void)
{
  __asm 
  {
    mov dword ptr a, eax
  }
  res = nextBlock++;
  *res = __gettime(*(double*)a);
  __asm 
  {
    mov eax, res
  }
}
__declspec ( naked ) void _asm_gettime_end(void) {}
